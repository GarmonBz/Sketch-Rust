CADdillo free CAD block library
===============================

413 blocks, DXF R2018, drawn in inches.

Free to download and free to use — commercial work included. No
attribution required, no per-seat license, no symbol-pack invoice.

Open any of them in the CADdillo editor in your browser:
  https://app.caddillo.com

Per-block pages with dimensions, insertion datums and parameters:
  https://caddillo.com/blocks/

Categories
----------
  architectural              25  Architectural
  commercial-ada             27  Commercial ADA
  commercial-office          34  Commercial Office
  commercial-plumbing        23  Commercial Plumbing
  commercial-safety           7  Commercial Safety
  commercial-security        12  Commercial Security
  electrical                  7  Electrical
  industrial                 33  Industrial
  kitchen                    22  Kitchen
  pid                         8  P&ID
  plumbing                   31  Plumbing
  residential-appliance       5  Residential Appliances
  residential-furniture      73  Residential Furniture
  residential-me              7  Residential Mechanical / Electrical
  site                       25  Site / Exterior
  conduit                    27  Electrical Conduit (MEP)
  duct                       22  HVAC Duct (MEP)
  sprinkler                  25  Fire Sprinkler (MEP)

Every block is parametric where it matters — the editor exposes the
adjustable parameters listed on each block's page on caddillo.com.

— Quantum Armadillo, LLC
